#!/usr/bin/python3

from distutils.core import setup, Extension

module = Extension("putchar", sources = ["putchar.c"])
setup(name="putchar", version="1.0", description="Putchar package", ext_modules=[module])
