#include "Python.h"
#include <stdio.h>

static PyObject *Putchar(PyObject *self, PyObject *args) {
    int _char;
    PyArg_ParseTuple(args, "i", &_char);
    printf("%c", _char);
    Py_RETURN_NONE;
}

static PyMethodDef methods[] = {
    {"putchar", Putchar, METH_VARARGS, "print a char by int"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef mod_def = {
    PyModuleDef_HEAD_INIT,
    "putchar",
    NULL,
    -1,
    methods
};

PyMODINIT_FUNC PyInit_putchar() {
    return PyModule_Create(&mod_def);
}

int main(int argc, char *argv[]) {
    Py_SetProgramName(argv[0]);
    Py_Initialize();
    PyInit_putchar();
    return 0;
}
